#ifndef HELPERS
#define HELPERS

int invert(int number);
void serialBegin( int baudrate );

#endif // HELPERS
